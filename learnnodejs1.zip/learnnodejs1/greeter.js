// greeter.js
module.exports = (who) => {
    console.log('Hello ' + who)
}